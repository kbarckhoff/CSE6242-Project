# ZORI ZIP-Code Data Cleaning & Prep

This notebook loads, reshapes, cleans, and enriches Zillow’s Observed Rent Index (ZORI) at the ZIP-code level.
These steps prepare the data for volatility modeling, seasonality analysis, and 3–12-month forecasting in later notebooks.

Primary tasks:

* <b>Load & reshape the wide-format ZORI dataset</b>

* <b>Assess and handle missingness in rent values</b>

* <b>Repair missing ZIP-level metadata (e.g., City)</b>

* <b>Engineer volatility features and export a clean dataset</b>

## 1. Imports & Setup

These packages support data loading (local + GCS), reshaping, visual diagnostics, and USPS ZIP lookup.


```python
import pandas as pd
import numpy as np
import gcsfs
from joblib import Parallel, delayed
import seaborn as sns
import matplotlib.pyplot as plt
from uszipcode import SearchEngine
```

    /opt/anaconda3/lib/python3.13/site-packages/fuzzywuzzy/fuzz.py:11: UserWarning: Using slow pure-python SequenceMatcher. Install python-Levenshtein to remove this warning
      warnings.warn('Using slow pure-python SequenceMatcher. Install python-Levenshtein to remove this warning')


## 2. Load ZORI Data

We load Zillow’s ZIP-level time series directly from Google Cloud Storage. The source data is in wide format (one row per ZIP, one column per month).


```python
fs = gcsfs.GCSFileSystem(project='cse6242-project-476314', token = 'google_default')
with fs.open('cse6242-project-data-bucket/Zip_zori_uc_sfrcondomfr_sm_sa_month.csv') as f:
    zori_wide = pd.read_csv(f, dtype={'RegionName': str})

# use local for initial testing
#zori_wide = pd.read_csv('Zip_zori_uc_sfrcondomfr_sm_sa_month.csv')
#zori_wide
```

## 3. Reshape Data to Long Format

ZORI distributes months as separate columns.
We “melt” into long format for easier time-series operations.

Time-series forecasting, missingness analysis, and volatility calculations require one row per ZIP × month.


```python
# get into long format
value_vars = [col for col in zori_wide.columns if col[:4].isdigit()]

zori = zori_wide.melt(
    id_vars=['RegionID', 'SizeRank', 'RegionName', 'RegionType', 'StateName', 'State', 'City', 'Metro', 'CountyName'],
    value_vars = value_vars,
    var_name='Date',
    value_name='Rent'
)

# standardize date
zori['Date'] = pd.to_datetime(zori['Date'])
zori['Date'] = zori['Date'].dt.to_period('M').dt.to_timestamp('M')


# rename RegionID to ZIP
zori = zori.rename(columns={'RegionName':'ZIP'})

# sort time series
zori = zori.sort_values(['ZIP', 'Date'])

zori
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RegionID</th>
      <th>SizeRank</th>
      <th>ZIP</th>
      <th>RegionType</th>
      <th>StateName</th>
      <th>State</th>
      <th>City</th>
      <th>Metro</th>
      <th>CountyName</th>
      <th>Date</th>
      <th>Rent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3692</th>
      <td>58197</td>
      <td>3911</td>
      <td>01002</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2015-01-31</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>11545</th>
      <td>58197</td>
      <td>3911</td>
      <td>01002</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2015-02-28</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>19398</th>
      <td>58197</td>
      <td>3911</td>
      <td>01002</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2015-03-31</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>27251</th>
      <td>58197</td>
      <td>3911</td>
      <td>01002</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2015-04-30</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>35104</th>
      <td>58197</td>
      <td>3911</td>
      <td>01002</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2015-05-31</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>977970</th>
      <td>100459</td>
      <td>4499</td>
      <td>99801</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>2025-05-31</td>
      <td>2086.647581</td>
    </tr>
    <tr>
      <th>985823</th>
      <td>100459</td>
      <td>4499</td>
      <td>99801</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>2025-06-30</td>
      <td>2106.771773</td>
    </tr>
    <tr>
      <th>993676</th>
      <td>100459</td>
      <td>4499</td>
      <td>99801</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>2025-07-31</td>
      <td>2071.056317</td>
    </tr>
    <tr>
      <th>1001529</th>
      <td>100459</td>
      <td>4499</td>
      <td>99801</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>2025-08-31</td>
      <td>2061.207785</td>
    </tr>
    <tr>
      <th>1009382</th>
      <td>100459</td>
      <td>4499</td>
      <td>99801</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>2025-09-30</td>
      <td>2030.000000</td>
    </tr>
  </tbody>
</table>
<p>1013037 rows × 11 columns</p>
</div>



## 4. Inspect Data Structure & Missingness

### 4.1 Basic structure


```python
zori.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 1013037 entries, 3692 to 1009382
    Data columns (total 11 columns):
     #   Column      Non-Null Count    Dtype         
    ---  ------      --------------    -----         
     0   RegionID    1013037 non-null  int64         
     1   SizeRank    1013037 non-null  int64         
     2   ZIP         1013037 non-null  object        
     3   RegionType  1013037 non-null  object        
     4   StateName   1013037 non-null  object        
     5   State       1013037 non-null  object        
     6   City        1005555 non-null  object        
     7   Metro       1008006 non-null  object        
     8   CountyName  1013037 non-null  object        
     9   Date        1013037 non-null  datetime64[ns]
     10  Rent        396233 non-null   float64       
    dtypes: datetime64[ns](1), float64(1), int64(2), object(7)
    memory usage: 92.7+ MB



```python
zori.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RegionID</th>
      <th>SizeRank</th>
      <th>Date</th>
      <th>Rent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.013037e+06</td>
      <td>1.013037e+06</td>
      <td>1013037</td>
      <td>396233.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>8.469800e+04</td>
      <td>4.770870e+03</td>
      <td>2020-05-30 20:39:04.186046720</td>
      <td>1814.321472</td>
    </tr>
    <tr>
      <th>min</th>
      <td>5.819700e+04</td>
      <td>1.000000e+00</td>
      <td>2015-01-31 00:00:00</td>
      <td>528.828904</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7.036500e+04</td>
      <td>2.037000e+03</td>
      <td>2017-09-30 00:00:00</td>
      <td>1301.376023</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.948800e+04</td>
      <td>4.178000e+03</td>
      <td>2020-05-31 00:00:00</td>
      <td>1649.037387</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>9.326100e+04</td>
      <td>6.735000e+03</td>
      <td>2023-01-31 00:00:00</td>
      <td>2128.800125</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8.459140e+05</td>
      <td>3.049000e+04</td>
      <td>2025-09-30 00:00:00</td>
      <td>99629.555556</td>
    </tr>
    <tr>
      <th>std</th>
      <td>4.216436e+04</td>
      <td>3.566825e+03</td>
      <td>NaN</td>
      <td>1108.741032</td>
    </tr>
  </tbody>
</table>
</div>



### 4.2 Missing values count


```python
zori.isna().sum()
```




    RegionID           0
    SizeRank           0
    ZIP                0
    RegionType         0
    StateName          0
    State              0
    City            7482
    Metro           5031
    CountyName         0
    Date               0
    Rent          616804
    dtype: int64



## 5. Missingness Analysis

### 5.1 Detect inconsistent gaps
Check if any ZIPs skip months (should be monthly frequency):


```python
# spacing
zori['gap_days']  = zori.groupby('ZIP')['Date'].diff().dt.days
anomalies = zori[zori['gap_days'] > 31]
anomalies.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RegionID</th>
      <th>SizeRank</th>
      <th>ZIP</th>
      <th>RegionType</th>
      <th>StateName</th>
      <th>State</th>
      <th>City</th>
      <th>Metro</th>
      <th>CountyName</th>
      <th>Date</th>
      <th>Rent</th>
      <th>gap_days</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



### 5.2 Standardize the Time Index
We reindex all ZIPs to a complete, uniform timeline:

<b>Jan-2015 through Dec-2024.</b>

This ensures every ZIP has the same number of rows.


```python
full_index = pd.date_range('2015-01-01', '2024-12-01', freq='ME')

zori2 = zori.copy()
zori2['Date'] = pd.to_datetime(zori2['Date']).dt.to_period('M').dt.to_timestamp('M')

zori2 = (
    zori2
    .set_index('Date')
    .groupby('ZIP')
    .apply(lambda x: x.drop(columns='ZIP').reindex(full_index)) 
    .rename_axis(index=['ZIP', 'Date'])
    .reset_index()  
)

zori2
```

    /var/folders/v6/rt7shrqx5sldb75bkwymnhlw0000gp/T/ipykernel_69437/3203717608.py:10: DeprecationWarning: DataFrameGroupBy.apply operated on the grouping columns. This behavior is deprecated, and in a future version of pandas the grouping columns will be excluded from the operation. Either pass `include_groups=False` to exclude the groupings or explicitly select the grouping columns after groupby to silence this warning.
      .apply(lambda x: x.drop(columns='ZIP').reindex(full_index))





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ZIP</th>
      <th>Date</th>
      <th>RegionID</th>
      <th>SizeRank</th>
      <th>RegionType</th>
      <th>StateName</th>
      <th>State</th>
      <th>City</th>
      <th>Metro</th>
      <th>CountyName</th>
      <th>Rent</th>
      <th>gap_days</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01002</td>
      <td>2015-01-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01002</td>
      <td>2015-02-28</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>NaN</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01002</td>
      <td>2015-03-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01002</td>
      <td>2015-04-30</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>NaN</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01002</td>
      <td>2015-05-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>934502</th>
      <td>99801</td>
      <td>2024-07-31</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>934503</th>
      <td>99801</td>
      <td>2024-08-31</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>934504</th>
      <td>99801</td>
      <td>2024-09-30</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>934505</th>
      <td>99801</td>
      <td>2024-10-31</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>934506</th>
      <td>99801</td>
      <td>2024-11-30</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>30.0</td>
    </tr>
  </tbody>
</table>
<p>934507 rows × 12 columns</p>
</div>



### 5.3 Missingness by State and Month

This helps us understand geographic and temporal patterns in missing ZORI values.


```python
zip_missing = (
    zori2.groupby(['State', 'ZIP'])['Rent']
        .apply(lambda s: s.isna().sum())
        .reset_index(name='missing')
)

zip_missing.groupby('State')['missing'].apply(lambda x: (x > 0).mean()).sort_values()
```




    State
    NV    0.581395
    AZ    0.620321
    FL    0.771982
    GA    0.810700
    VA    0.859223
    NY    0.869919
    NC    0.874459
    TX    0.893408
    DC    0.909091
    NM    0.921053
    CA    0.926045
    MA    0.926966
    IL    0.928287
    ID    0.931818
    HI    0.933333
    RI    0.939394
    CO    0.939560
    MD    0.941176
    TN    0.945578
    WA    0.950226
    SC    0.957983
    MI    0.961722
    OR    0.967480
    PA    0.967742
    OK    0.970588
    IN    0.974684
    NJ    0.978166
    CT    0.980952
    MO    0.981013
    AR    0.983051
    KS    0.986667
    MN    0.992806
    OH    0.996154
    AK    1.000000
    VT    1.000000
    WI    1.000000
    SD    1.000000
    UT    1.000000
    MS    1.000000
    NE    1.000000
    ND    1.000000
    MT    1.000000
    WV    1.000000
    ME    1.000000
    LA    1.000000
    KY    1.000000
    IA    1.000000
    DE    1.000000
    AL    1.000000
    NH    1.000000
    WY    1.000000
    Name: missing, dtype: float64



### 5.3 Visualize ZIP x Time Missingness


```python
missing_by_month = (
    zori2.groupby('Date')['Rent']
        .apply(lambda s: s.isna().mean())
        .reset_index(name='pct_missing')
)

missing_by_month
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>pct_missing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2015-01-31</td>
      <td>0.895454</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-02-28</td>
      <td>0.891761</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015-03-31</td>
      <td>0.884885</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015-04-30</td>
      <td>0.883102</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015-05-31</td>
      <td>0.880810</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>114</th>
      <td>2024-07-31</td>
      <td>0.282695</td>
    </tr>
    <tr>
      <th>115</th>
      <td>2024-08-31</td>
      <td>0.281166</td>
    </tr>
    <tr>
      <th>116</th>
      <td>2024-09-30</td>
      <td>0.277601</td>
    </tr>
    <tr>
      <th>117</th>
      <td>2024-10-31</td>
      <td>0.267923</td>
    </tr>
    <tr>
      <th>118</th>
      <td>2024-11-30</td>
      <td>0.261811</td>
    </tr>
  </tbody>
</table>
<p>119 rows × 2 columns</p>
</div>




```python
missing_by_month.plot(x='Date', y='pct_missing')
```




    <Axes: xlabel='Date'>




    
![png](output_22_1.png)
    



```python
def missing_streak_length(series):
    return series.isna().groupby((~series.isna()).cumsum()).sum().max()

zip_missing_streak = (
    zori2.groupby('ZIP')['Rent']
        .apply(missing_streak_length)
        .reset_index(name='max_missing_streak')
)

zip_missing_streak.sort_values('max_missing_streak', ascending=False).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ZIP</th>
      <th>max_missing_streak</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3926</th>
      <td>48423</td>
      <td>119</td>
    </tr>
    <tr>
      <th>3643</th>
      <td>46036</td>
      <td>119</td>
    </tr>
    <tr>
      <th>3647</th>
      <td>46052</td>
      <td>119</td>
    </tr>
    <tr>
      <th>3648</th>
      <td>46055</td>
      <td>119</td>
    </tr>
    <tr>
      <th>3651</th>
      <td>46064</td>
      <td>119</td>
    </tr>
  </tbody>
</table>
</div>




```python
sample = zori2.pivot(index='ZIP', columns='Date', values='Rent')
plt.figure(figsize=(14,8))
sns.heatmap(sample.isna(), cbar=False)
plt.title("Missing Rent Data by ZIP × Month")
```




    Text(0.5, 1.0, 'Missing Rent Data by ZIP × Month')




    
![png](output_24_1.png)
    


## 6. Impute Missing Rent Values

We use linear interpolation within each ZIP.

<b>Why linear interpolation?</b>

* Avoids distortions in seasonal decomposition
* Preserves month-to-month smoothness
* Works well for ZORI, which is already smoothed by Zillow


```python
def interpolate_zip(series):
    s = series.astype(float).copy()

    return s.interpolate(method='linear', limit_direction='both')
```

Apply per ZIP:


```python
df_interpolated = (
    zori2
        .groupby('ZIP', group_keys=False)
        .apply(lambda g: g.assign(Rent=interpolate_zip(g['Rent'])))
        .reset_index(drop=True)
)
```

    /var/folders/v6/rt7shrqx5sldb75bkwymnhlw0000gp/T/ipykernel_69437/3954869825.py:4: DeprecationWarning: DataFrameGroupBy.apply operated on the grouping columns. This behavior is deprecated, and in a future version of pandas the grouping columns will be excluded from the operation. Either pass `include_groups=False` to exclude the groupings or explicitly select the grouping columns after groupby to silence this warning.
      .apply(lambda g: g.assign(Rent=interpolate_zip(g['Rent'])))



```python
df_interpolated
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ZIP</th>
      <th>Date</th>
      <th>RegionID</th>
      <th>SizeRank</th>
      <th>RegionType</th>
      <th>StateName</th>
      <th>State</th>
      <th>City</th>
      <th>Metro</th>
      <th>CountyName</th>
      <th>Rent</th>
      <th>gap_days</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01002</td>
      <td>2015-01-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01002</td>
      <td>2015-02-28</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01002</td>
      <td>2015-03-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01002</td>
      <td>2015-04-30</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01002</td>
      <td>2015-05-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>934502</th>
      <td>99801</td>
      <td>2024-07-31</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>934503</th>
      <td>99801</td>
      <td>2024-08-31</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>934504</th>
      <td>99801</td>
      <td>2024-09-30</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>934505</th>
      <td>99801</td>
      <td>2024-10-31</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>934506</th>
      <td>99801</td>
      <td>2024-11-30</td>
      <td>100459</td>
      <td>4499</td>
      <td>zip</td>
      <td>AK</td>
      <td>AK</td>
      <td>Juneau</td>
      <td>Juneau, AK</td>
      <td>Juneau Borough</td>
      <td>NaN</td>
      <td>30.0</td>
    </tr>
  </tbody>
</table>
<p>934507 rows × 12 columns</p>
</div>



### 6.1 Identify ZIP Codes with Unreliable Imputation

Compute the longest consecutive missing streak before interpolation:


```python
df_interpolated['missing_after'] = df_interpolated.groupby('ZIP')['Rent'].transform(lambda s: s.isna().sum())

missing_summary = (
    df_interpolated.groupby('ZIP')['Rent']
         .apply(lambda s: s.isna().sum())
         .reset_index(name='missing_count')
)

# How many ZIPs have missing values?
num_zip_with_missing = (missing_summary['missing_count'] > 0).sum()

num_zip_with_missing
```




    np.int64(2020)




```python
# proportion of missing vs total zips
total_zips = missing_summary.shape[0]
percentage = num_zip_with_missing / total_zips * 100
percentage
```




    np.float64(25.72265376289316)



Drop ZIPs with > 24 consecutive missing months.


```python
def longest_gap(s):
    mask = s.isna()
    return mask.groupby((~mask).cumsum()).sum().max()

zip_bad = (
    df_interpolated.groupby('ZIP')['Rent']
                   .apply(longest_gap)
                   .reset_index(name='longest_gap')
)

good_zips = zip_bad[zip_bad['longest_gap'] <= 24]['ZIP']

good_zips.nunique()
```




    5833




```python
df_interpolated_final = df_interpolated[df_interpolated['ZIP'].isin(good_zips)].copy()
```

## 7. Repair Missing City Names

USPS provides a reliable primary city for each ZIP.


```python
search = SearchEngine()

def get_city(zipcode):
    z = search.by_zipcode(zipcode)
    return z.major_city
```


```python
# Get the primary city for each ZIP code
df_interpolated_final.loc[:, 'ZIP'] = (
    df_interpolated_final['ZIP']
        .astype(str)
        .str.zfill(5)   # fix any that aren't padded correctly 1002 -> 01002
)

unique_zips = df_interpolated_final['ZIP'].drop_duplicates()

zip_city_map = {
    z: get_city(z) for z in unique_zips
}

df_interpolated_final.loc[:, 'City'] = df_interpolated_final['ZIP'].map(zip_city_map)
```


```python
df_interpolated_final.isna().sum()
```




    ZIP                 0
    Date                0
    RegionID            0
    SizeRank            0
    RegionType          0
    StateName           0
    State               0
    City                0
    Metro               0
    CountyName          0
    Rent                0
    gap_days         5833
    missing_after       0
    dtype: int64



## 8. Feature Engineering

### 8.1 Month-over-month % Change


```python
df_interpolated_final.loc[:, 'pct_change'] = (df_interpolated_final.groupby('ZIP')['Rent'].transform(lambda s: s.pct_change()))
```

### 8.2 Rolling 12-month Volatility

This is the standard deviation of percent changes.


```python
df_interpolated_final.loc[:, 'Volatility'] = (df_interpolated_final.groupby('ZIP')['pct_change'].transform(lambda s: s.rolling(12, min_periods=6).std()))
```

## 9. Final Cleaning and Export


```python
df_final = df_interpolated_final.copy()
df_final.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 694127 entries, 0 to 934268
    Data columns (total 15 columns):
     #   Column         Non-Null Count   Dtype         
    ---  ------         --------------   -----         
     0   ZIP            694127 non-null  object        
     1   Date           694127 non-null  datetime64[ns]
     2   RegionID       694127 non-null  int64         
     3   SizeRank       694127 non-null  int64         
     4   RegionType     694127 non-null  object        
     5   StateName      694127 non-null  object        
     6   State          694127 non-null  object        
     7   City           694127 non-null  object        
     8   Metro          694127 non-null  object        
     9   CountyName     694127 non-null  object        
     10  Rent           694127 non-null  float64       
     11  gap_days       688294 non-null  float64       
     12  missing_after  694127 non-null  int64         
     13  pct_change     688294 non-null  float64       
     14  Volatility     659129 non-null  float64       
    dtypes: datetime64[ns](1), float64(4), int64(3), object(7)
    memory usage: 84.7+ MB


Drop intermediate columns:


```python
cols_to_drop = ['StateName', 'gap_days', 'missing_after', 'pct_change']
df_final = df_final.drop(columns=cols_to_drop)
df_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ZIP</th>
      <th>Date</th>
      <th>RegionID</th>
      <th>SizeRank</th>
      <th>RegionType</th>
      <th>State</th>
      <th>City</th>
      <th>Metro</th>
      <th>CountyName</th>
      <th>Rent</th>
      <th>Volatility</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01002</td>
      <td>2015-01-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01002</td>
      <td>2015-02-28</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01002</td>
      <td>2015-03-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01002</td>
      <td>2015-04-30</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01002</td>
      <td>2015-05-31</td>
      <td>58197</td>
      <td>3911</td>
      <td>zip</td>
      <td>MA</td>
      <td>Amherst</td>
      <td>Springfield, MA</td>
      <td>Hampshire County</td>
      <td>2608.712894</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



Export:


```python
df_final.to_csv('clean_zori.csv', index=False)
df_final.to_parquet('clean_zori.parquet', index=False, compression='snappy')
```
